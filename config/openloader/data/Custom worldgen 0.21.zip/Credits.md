Custom worldgen datapack built using the following tools:

- Snowcapped by jacobsjo
  - https://snowcapped.jacobsjo.eu/
- Customized Worlds by Misode
  - https://misode.github.io/